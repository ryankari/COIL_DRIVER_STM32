

#ifndef INTERRUPTHANDLES_H
		#define INTERRUPTHANDLES_H

	#define ID_Buffer0 1230
	#define ID_Buffer1 1231
	#define ID_Buffer2 1232
	#define ID_Buffer3 1233
	#define ID_Buffer4 1234



#endif
